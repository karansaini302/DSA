package Main;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import Dancing.DanceShow;

/**
 * The purpose of this class is to generate {@link DanceShow}s along with their
 * {@link Dance}s.
 * 
 * 
 *
 */
public class DanceShowGenerator {

	private Scanner scanner; // Scanner object to read input .csv files
	private HashMap<String, Set<String>> danceGroups; // Key: Name of Dance Group ---- Value: Set of Dancers
	private HashMap<String, Set<String>> dances; // Key: Name of Dance ---- Value: Set of Dancers and guest
													// performers

	public DanceShowGenerator(String dancesFilePath, String danceGroupsFilePath) {

		danceGroups = new HashMap<String, Set<String>>();
		dances = new HashMap<String, Set<String>>();

		createDanceGroups(danceGroupsFilePath);
		createDances(dancesFilePath);

	}

	/**
	 * Creates a HashMap with a set of dance groups.
	 * 
	 * @param danceGroupsFilePath
	 */
	private void createDanceGroups(String danceGroupsFilePath) {

		File file = new File(danceGroupsFilePath);

		try {
			scanner = new Scanner(file);

			scanner.nextLine(); // should skip the title of the column

			// initialises an ArrayList of Strings for the separated Dance Names.
			ArrayList<String> names = new ArrayList<String>();

			while (scanner.hasNext()) {
				String lineOfDanceNames = scanner.nextLine();

				String[] dancesSplitByTab = lineOfDanceNames.split("\t");

				// Converts the array of names scanned in into an ArrayList collection of
				// Strings
				for (String name : Arrays.asList(dancesSplitByTab[1])) {
					names.add(name);
				}

				// Puts the dance groups and their listed performers into a set into a hashmap
				danceGroups.put(dancesSplitByTab[0], new TreeSet<String>(names));

			}

//			//test
//			for(String group : danceGroups.keySet()) {
//				for(String member : danceGroups.get(group)) {
//					System.out.println(member);
//				}
//			}

//			System.out.println(danceGroups.get("Juniors"));

			// searchForPerformer();

			// Closes the scanner
			scanner.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private String searchForPerformer(String name) {
		// Goes through each name in dance group
		for (String key : danceGroups.keySet()) {
			for (String members : danceGroups.get(key)) {
				String[] dancers = members.split(", ");
				if (Arrays.asList(dancers).contains(name)) {
					return name;
				} else {
					return null;
				}
			}

//			Iterator<String> i = danceGroups.get(key).iterator();
//			while (i.hasNext()) {
//				// System.out.println(i.next().toString());
//
//				String[] dancers = i.next().split(", ");
//				if (Arrays.asList(dancers).contains(name)) {
//					for (String performer : dancers) {
//						if (performer.equals(name)) {
//							return name;
//						}
//					}
//				}
//			}
		}
		return null;
	}

	private void createDances(String dancesFilePath) {
		File file = new File(dancesFilePath);
		List<String> dancers = new ArrayList<String>();

		try {
			scanner = new Scanner(file);

			scanner.nextLine(); // skips the category name (Dance Name) title and goes to the next line

			while (scanner.hasNext()) {

				String lineOfDanceNames = scanner.nextLine();

				String[] dancesSplitByTab = lineOfDanceNames.split("\t");

//				System.out.println(dances[1]); //array index 1 (dances[1]) represents the dancers
//				System.out.println(dances[0]); //array index 0 (dances[0]) represents the name of the dances 
//				System.out.print(inputStream.nextLine() + "-------");
//				for(String dance : dances) {
//					System.out.println(dance + " THIS IS A LINE");
//				}
				// System.out.println(data + "ITS HAPPENING");

				String[] performers = dancesSplitByTab[1].split(", ");

				// THIS IS A TEST TO SEE IF ALL PERFORMERS HAVE BEEN PARSED CORRECTLY
//				for(int i = 0; i < performers.length;i++) {
//					System.out.println(performers[i] + " THIS IS A DANCER");
//				}
//				
//				System.out.println("------------");

				// can delete this
//				for(String group : danceGroups.keySet()) {
//					for(String member : danceGroups.get(group)) {
//						System.out.println(member);
//					}
//				}

				for (String performer : Arrays.asList(performers)) {

					// bunch of conditions to decide which dancers to put into each dance

					boolean performerFound = false;

					// if a dancer with the same name was found in group/set of dancers
					if (performerFound == true) {
						dancers.add(performer);
					}

					// if the dancer isn't empty and it fills but does not equal the the current
					// dancer and is not a guest already (puts in a set of dancers)
					else if (performerFound == false && searchForPerformer(performer) != null) {
						// go to list of groups
						// adds all dance members from group
						// in this case performer is the name of the group

						for (String group : danceGroups.keySet()) {
							for (String member : danceGroups.get(group)) {
								dancers.add(member);
							}
						}



//						dancers.addAll(danceGroups.get(performer));

					}

//					else if (searchForPerformer(performer) == null) {
////						throw new NullPointerException("THIS DANCER WAS NOT FOUND");
////						System.out.println(performer);
////						System.out.println("BEEP BOOP SOMETHING WENT WRONG");
//					}

				}

				// Puts the name of the dance in as a key along with a Tree Set of the relevant
				// dancers
				dances.put(dancesSplitByTab[0], new TreeSet<String>(dancers));

			}

			scanner.close();
//			//TEST TO MAKE SURE ALL DANCE NAMES ARE THERE
//			for (String dance : dances.keySet()) {
//				System.out.println(dance);
//			}


		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * THE KEY IS THE NAME OF THE DANCE GROUP, SET IS THE MEMBERS
	 * @return
	 */
	public HashMap<String, Set<String>> getDanceGroups() {
		return danceGroups;
	}
	
	/**
	 * THE KEY IS THE NAME OF THE DANCE, SET IS THE DANCERS
	 * 
	 * @return
	 */
	public HashMap<String, Set<String>> getDances() {
		return dances;
	}
}
