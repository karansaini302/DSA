package Main;

public class TextUserInterface {

	public TextUserInterface() {
		
	}
}
