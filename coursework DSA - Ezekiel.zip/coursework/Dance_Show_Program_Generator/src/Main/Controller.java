package Main;

import Dancing.*;

public interface Controller {

	public void listPerformers(Dance dance);
	public void listDanceNumbersandPerformers();
	public DanceShow generateRunningOrder();
	public DanceShow giveRunningOrder(DanceShow danceShow);
	
}
