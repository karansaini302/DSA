package Main;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

import Dancing.Dance;
import Dancing.DanceShow;

public class Main implements Controller{

	public static void main(String[] args) {
		DanceShowGenerator dGenerator = new DanceShowGenerator("astaire/danceShowData_dances.csv", "astaire/danceShowData_danceGroups.csv");
	
		HashMap<String,Set<String>> dances = dGenerator.getDances();
		
		//TESTS
//		for(String danceName : dances.keySet()) {
//			for(String performer : dances.get(danceName)) {
//				System.out.println(performer);
//			}
//		}
	
		//TESTS
//		HashMap<String, Set<String>> danceGroups = dGenerator.getDanceGroups();
//		
//		for(String danceGroup : danceGroups.keySet()) {
//			System.out.println(danceGroup);
//			for(String dancer : danceGroups.get(danceGroup)) {
//				System.out.println(dancer);
//			}
//		}
		
	}

	/**
	 * Iterates through the running order of dances and checks whether there will be
	 * enough time for each dancer to change their costume between their dances
	 * 
	 * @return
	 */
	private boolean checkFeasibilityOfOrder() {
		return false;
	}

	@Override
	public void listPerformers(Dance dance) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void listDanceNumbersandPerformers() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public DanceShow generateRunningOrder() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DanceShow giveRunningOrder(DanceShow danceShow) {
		// TODO Auto-generated method stub
		return null;
	}
}
