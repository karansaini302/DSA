package Dancing;

import java.util.SortedSet;
import java.util.TreeSet;

public class Dance {
	
	private String danceName;
	private SortedSet<String> performers = new TreeSet<>();
	
	
	//The constructor
	public Dance(String a, SortedSet<String> b) {
		danceName = a;
		performers.addAll(b);
		
	}
	
	public Dance(String DanceName, String performer) {
		danceName = DanceName;
		performers.add(performer);
	}
	
	//Return the set of dances?
	public SortedSet<String> getDances() {
		return performers;
	}
	
	//Return the name of the dance
	public String getName() {
		return danceName;
	}
	
	//Add a set of performers
	public void addDanceGroup(SortedSet<String> b) {
		performers.addAll(b);
	}
	
	//Add a single performer to a dance
	public void addSingleDancer(String a) {
		performers.add(a);
	}
	
	//List performers
	public void listPerformers() {
		System.out.println("Performers for " + danceName + " are " + performers);
	}

	//Get the performers
	public SortedSet<String> getPerformers() {
		return performers;
	}
	
	
	
	
	
	

}
