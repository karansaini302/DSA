package Dancing;

import java.util.HashMap;

/**
 * Don't need this apparently
 * 
 * @author gamin
 *
 */
public class DanceGroup {
	
	protected HashMap<String, Dancer> groupMembers;
	protected String groupType;
	
	protected DanceGroup(String mKey, Dancer mVal) {
		groupMembers = new HashMap<>();
		groupMembers.put(mKey, mVal);
	}
	
	protected void act() {
		
	}
	
	
	
	

}
