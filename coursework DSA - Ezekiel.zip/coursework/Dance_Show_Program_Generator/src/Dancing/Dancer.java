package Dancing;

import java.util.SortedSet;

public class Dancer {


	private String dancerName;
	private SortedSet<String> dancers;
	private
	
	//Group Names - Pre-primaries,primaries,juniors, intermediates, seniors, cabaret girls, happy tappers
	/*Pre-primaries	Molly, Aimee, Abby, June, Mae, May, Danielle
	Primaries	Lucy, Cathy, April, Laura, Dora, Agnes
	Juniors	Lily, Betty, Megan, Moria, Felicity, Susan
	Intermediates	Laura, Florence, Vivian, Ivy, Sally, Gwen, Arwen
	Seniors	Christine, Jenny, Kathryn, Ada, Darrell, Alicia, Mavis
	Cabaret Girls	Flora, Anne, Lucy, Kate, Gwen, Jane, Mary, Donna, Fiona, Grace
	Happy Tappers	Marianne, Dorothy, Audrey, Ginger, Teresa
*/
	public Dancer(String x) {
		dancerName = x;
	}
	
	
	public String returnName() {
		return dancerName;
	}
	
	
	
	public void displayDancer() {
		System.out.println("Name:" + returnName());
	}
	
	
	public void setDancers(SortedSet<String> n){
		 dancers = n;
	}
	
	
	public SortedSet<String> getMultipleDancers() {
		return dancers;
	}
	
	
	
	
}
