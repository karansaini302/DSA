package Dancing;

public abstract class Performer {
	private String name;
	private int numberOfPerformers;
	
	public Performer(String name) {
		this.name = name;
		numberOfPerformers = 0;
	}
	
	public void act() {}
	public String getName() {
		return name;
	}
	public int getNumberOfPerformers() {
		return numberOfPerformers;
	}

}
