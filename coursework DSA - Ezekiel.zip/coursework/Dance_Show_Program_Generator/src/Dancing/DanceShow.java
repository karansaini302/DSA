package Dancing;

import java.util.SortedSet;
import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;


public class DanceShow {

	
	/*CSV file data - for reference - delete in final
	 * Dance Name	Performers
	1   Singing in the Rain	Chris, Juniors
	2   The Candy Man Can	 Primaries, Alicia
	3	Let's Pretend	  Sandy, Carrie, Mindy, Pre-primaries
	4	Thoroughly Modern Milly	     Seniors
	5	Doe-Re-Mi  	 Juniors, Primaries, Chris
	6	What a Feeling	  Christine, Jenny
	7	Make 'em Laugh	  Juniors
	8	All That Jazz	    Cabaret Girls
	9	Juvenile Tap	    Primaries
	10	Bronze Tap	    Juniors
	11	Silver Tap	    Intermediates
	12	Gold Tap	    Seniors
	*/
	
	//Meet 2nd requirement
	
	
	protected int danceNumber;
	protected static int danceCounter;
	protected Dance dance;
	//protected SortedSet<String> performers = new TreeSet<>();
	

	
	//DanceShow constructor - needs a dance object
	protected DanceShow(Dance d) {
		dance = d;
		danceCounter++;
		danceNumber = danceCounter;
	}

	//List performers and the dance number
	protected void danceNumberAndPerformers() {
		System.out.println("Dance number for the dance show is " + danceNumber  + "\n The performers in this show " + dance.getPerformers());
	}
	
	//Generate a random dance show, required to be time feasible
	protected void generateDanceShow(List<Dance> allDances) {
		Random rng = new Random();
		int randomLength = rng.nextInt(35) + 1;
		List<Dance> newDances = new ArrayList<Dance>();
		
		//Loop for the 
		for(int i = 0; i <= randomLength; i++) {
			int randomPick = rng.nextInt(randomLength);
			newDances.add(allDances.get(randomPick));
		}
		
		checkDance(newDances);
		
	}
	
	
	protected List<Dance> checkDance(List<Dance> dancesToIterate) {
		//Iterate through the randomized list
		List<Dance> newList = new ArrayList<Dance>();
		
		for(int i = 0; i <= dancesToIterate.size(); i++) {
			//Returns true if no common elements are found in the two lists
			if(Collections.disjoint(dancesToIterate.get(i).getPerformers(),dancesToIterate.get(i+1).getPerformers() ) == true) {
				newList.add(dancesToIterate.get(i));
				//Adds an dance to the new random list if there is no clash of performers
			}
		}
		return newList;
		
	}
	
	
	
	
	
	
	/* Usefull but unused code
	//Single performer
	protected DanceShow(String name) {
		performers.add(name);
		danceCounter++;
	}
	
	//Add 2 performers
	protected DanceShow(String name, String name2) {
		performers.add(name);
		performers.add(name2);
		danceCounter++;
	}
	
	//Add 3 performers
	protected DanceShow(String name, String name2,String name3) {
		performers.add(name);
		performers.add(name2);
		performers.add(name3);
		danceCounter++;
	}
	
	// Add a set to the damn thing
	protected DanceShow(SortedSet<String> set) {
		performers.addAll(set);
		danceCounter++;
	}
	
	// Add 2 sets to the damn thing
	protected DanceShow(SortedSet<String> set1, SortedSet<String> set2) {
			performers.addAll(set1);
			performers.addAll(set2);
			danceCounter++;
	}
	
	//Adds a set of performers to the show
	protected void addPerformerSet(SortedSet<String> set1) {
		performers.addAll(set1);
	}
	
	//Add a single performer to the list
	protected void addPerformer(String n) {
		performers.add(n);
	}
	
	
	//Prints the contents of performer tree set
	protected void displayPerformers() {
		System.out.println(performers);
	}
	
	Set dance number
	protected void setDanceNumber(int x) {
		danceNumber = x;
	}
	
	
	//Get dance number
	protected int getDanceNumber() {
		return danceCounter;
	}
	
	//Will be used to sort by the dance number, constructor with a danceNumber and a performers
	//for the other parameter - sort by the dance number using a comparitor in the main
	protected void danceNumberAndPerformers() {
		System.out.println("Dance number for the dance show is " + danceCounter  + "\n The performers in this show " + performers);
	}
	
	
	*/
	
}
