package dancing;
import java.util.*;

public class Dance {
private String name;
private ArrayList<Dancer> dancers;
private int danceNumber;

public Dance(String danceName) {
	name = danceName;
	
}

public String getName() {
	return name;
}

public ArrayList<Dancer> getDancers(){
	return dancers;
}

public String listDanceNumbersAndPerformers(int danceNumber, Performer p){
	this.danceNumber = danceNumber;
	return danceNumber+p.getName();
}
}
