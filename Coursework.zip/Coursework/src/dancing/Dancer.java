package dancing;

public class Dancer {

	public Dancer(String name) {}
	public void act() {}
}
